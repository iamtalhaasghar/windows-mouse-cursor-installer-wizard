**Project Description**
"Cursor Installer Wizard" is simple application that create installation package for cursors. 


With this application you don't have to configure each cursor separately. Just create package and install your favorite cursor with two clicks.


# How to use

   1. Type in name of your cursor package and select your cursors than click "Create cursor package"
![](Home_1.PNG)
   2. Application will create zip file with your cursors and install file (Install.inf)
![](Home_2.PNG)
   3. Right click on Install.inf and select Install, system will copy your cursors to windows directory. Now you can find your cursor theme in mouse pointer configuration.
![](Home_3.PNG)